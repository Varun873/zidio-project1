// src/Quote.js
import React from 'react';

const Quote = () => {
  return (
    <div>
      <h2>Get A Quote</h2>
      {/* Add your Quote form or content here */}
    </div>
  );
};

export default Quote;
